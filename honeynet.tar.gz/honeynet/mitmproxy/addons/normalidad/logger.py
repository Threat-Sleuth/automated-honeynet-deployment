from mitmproxy import http
import json
import datetime

def response(flow: http.HTTPFlow) -> None:
    timestamp = datetime.datetime.now().isoformat()
    client_ip = flow.client_conn.address[0]
    client_port = flow.client_conn.address[1]
    server_name = flow.server_conn.address[0]

    request = {
        "host": flow.request.host,
        "method": flow.request.method,
        "scheme": flow.request.scheme,
        "authority": flow.request.authority,
        "url": flow.request.pretty_url,
        "path": flow.request.path,
        "http_version": flow.request.http_version,
        "trailers": flow.request.trailers,
        "timestamp_start_utc": datetime.datetime.fromtimestamp(flow.request.timestamp_start, tz=datetime.timezone.utc).isoformat().replace('+00:00',''),
        "timestamp_end_utc": datetime.datetime.fromtimestamp(flow.request.timestamp_end, tz=datetime.timezone.utc).isoformat().replace('+00:00',''),
        "duration": round(flow.request.timestamp_end - flow.request.timestamp_start, 6),
        "headers_size": sum(len(k) + len(v) + 4 for k, v in flow.request.headers.items()),
        "body_size": len(flow.request.content),
        "headers": dict(flow.request.headers),
        "body": flow.request.get_text(),
    } 

    response = {
        "http_version": flow.response.http_version,
	    "status_code": flow.response.status_code,
	    "reason": flow.response.reason,
	    "trailers": flow.response.trailers,
	    "timestamp_start_utc": datetime.datetime.fromtimestamp(flow.response.timestamp_start, tz=datetime.timezone.utc).isoformat().replace('+00:00',''),
	    "timestamp_end_utc": datetime.datetime.fromtimestamp(flow.response.timestamp_end, tz=datetime.timezone.utc).isoformat().replace('+00:00',''),
        "duration": round(flow.response.timestamp_end - flow.response.timestamp_start, 6),
        "headers_size": sum(len(k) + len(v) + 4 for k, v in flow.response.headers.items()),
        "body_size": len(flow.response.content),
        # Los siguientes dos atributos están desactivados por defecto, ya que sus valores aumentan signitivamente el
        # tamaño de los archivos de logs, sin aportar mucha información útil extra. Para activarlos basta con descomentar 
        # la línea correspondiente.
        # "headers": dict(flow.response.headers),
        # "body": flow.response.get_text(),
    }

    transaction = {
        "timestamp": timestamp,
        "client_ip": client_ip,
        "client_port": client_port,
        "server_name": server_name,
        "request": request,
        "response": response,
    }

    with open("/logs/dvwa_normalidad.log", "a") as f:
        f.write(f"{json.dumps(transaction)}\n")