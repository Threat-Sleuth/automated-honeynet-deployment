#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="${1:-/opt/honeynet/honeynet}"
cd "$ROOT_DIR"

EXPECTED=(
  fluentd
  ssh-normalidad ssh-pentesting
  ftp-normalidad ftp-pentesting
  dvwa-normalidad dvwa-pentesting
  reverse-proxy-normalidad reverse-proxy-pentesting
  mailserver-normalidad mailserver-pentesting
  db-normalidad db-pentesting
  api-normalidad api-pentesting
  smb-normalidad smb-pentesting
  vpn_normalidad vpn_pentesting
  wg-collector-normalidad wg-collector-pentesting
  portainer
)

failures=0

printf 'Validating Compose configuration...\n'
docker compose config --quiet

printf 'Checking expected containers...\n'
for container in "${EXPECTED[@]}"; do
  if ! docker inspect "$container" >/dev/null 2>&1; then
    printf '  [MISSING] %s\n' "$container"
    failures=$((failures + 1))
    continue
  fi

  state="$(docker inspect -f '{{.State.Status}}' "$container")"
  if [[ "$state" == "running" ]]; then
    printf '  [OK]      %s\n' "$container"
  else
    printf '  [%-7s] %s\n' "${state^^}" "$container"
    failures=$((failures + 1))
  fi
done

printf 'Checking Fluentd listener...\n'
if docker exec fluentd sh -c 'ss -lnt 2>/dev/null | grep -q ":24224" || netstat -lnt 2>/dev/null | grep -q ":24224"'; then
  printf '  [OK] Fluentd TCP/24224\n'
else
  printf '  [WARN] Fluentd listener could not be confirmed from inside the container.\n'
fi

printf 'Checking WireGuard collectors...\n'
for collector in wg-collector-normalidad wg-collector-pentesting; do
  if docker logs --tail 50 "$collector" 2>&1 | grep -q 'collector_started'; then
    printf '  [OK]      %s emits JSON\n' "$collector"
  else
    printf '  [WARN]    %s has not emitted collector_started\n' "$collector"
  fi
done

if (( failures > 0 )); then
  printf '\nValidation failed: %d required container(s) missing or not running.\n' "$failures" >&2
  exit 1
fi

printf '\nBaseline validation passed. Traffic-level validation is still required.\n'
