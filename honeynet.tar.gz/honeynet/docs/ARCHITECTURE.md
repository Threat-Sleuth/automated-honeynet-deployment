# Architecture

The honeynet deploys two parallel Docker environments: `normalidad` for benign traffic and `pentesting` for anomalous or attack traffic. Each environment contains SSH, FTP, DVWA, mail, PostgreSQL, FastAPI, SMB and WireGuard services.

Fluentd receives structured stdout/stderr streams through Docker's Fluentd logging driver. Mitmproxy records DVWA HTTP transactions, Samba `full_audit` records file operations, and the WireGuard collectors emit peer-state changes as JSON.

```text
CAUSALIS / clients
        |
  +-----+------+
  |            |
normalidad  pentesting
  |            |
8 services   8 services
  +-----+------+
        |
 Fluentd / Mitmproxy
        |
  persistent logs
```

The two traffic classes are separated by dedicated Docker bridge networks. Portainer is bound to localhost only.
