# Reproducibility

## Baseline environment

- Ubuntu 22.04 or 24.04 LTS
- 4 vCPUs
- 8 GiB RAM
- at least 12 GiB free disk space
- Docker Engine with the Compose plugin

## Procedure

1. Verify `SHA256SUMS`.
2. Run `sudo ./install_honeynet.sh` on a clean VM.
3. Record the detected `HOST_IP`, Docker version and Compose version.
4. Execute `scripts/validate_honeynet.sh` after startup.
5. Run a short benign and anomalous campaign against all service pairs.
6. Confirm that all sixteen log families receive events.
7. Preserve the release tag, configuration, campaign definition and generated dataset checksums with the experiment results.

Do not modify service images, credentials, port mappings or traffic profiles during a comparative experiment unless the change is explicitly documented.
