#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="${1:-/opt/honeynet/honeynet}"
ENV_FILE="${ENV_FILE:-/etc/default/honeynet}"
[[ -d "$ROOT_DIR" ]] || { echo "[FAIL] Missing project directory: $ROOT_DIR" >&2; exit 1; }
cd "$ROOT_DIR"
if [[ -r "$ENV_FILE" ]]; then set -a; source "$ENV_FILE"; set +a; fi
services=(fluentd portainer ssh_normalidad ssh_pentesting ftp_normalidad ftp_pentesting dvwa_normalidad dvwa_pentesting reverse_proxy_normalidad reverse_proxy_pentesting mailserver_normalidad mailserver_pentesting db_normalidad db_pentesting api_normalidad api_pentesting smb_normalidad smb_pentesting wireguard_normalidad wireguard_pentesting wg_collector_normalidad wg_collector_pentesting)
failed=0
for s in "${services[@]}"; do
  cid=$(docker compose ps -q "$s" 2>/dev/null || true)
  state=""
  [[ -n "$cid" ]] && state=$(docker inspect -f '{{.State.Status}}' "$cid" 2>/dev/null || true)
  if [[ "$state" == running ]]; then printf '[OK]   %s\n' "$s"; else printf '[FAIL] %s (%s)\n' "$s" "${state:-not-created}"; failed=1; fi
done
if docker compose exec -T wireguard_normalidad wg show >/dev/null 2>&1; then echo '[OK]   WireGuard command'; else echo '[WARN] WireGuard command unavailable'; fi
if docker compose logs --no-color --tail=20 fluentd 2>&1 | grep -qiE 'error|fatal'; then echo '[WARN] Fluentd recent logs contain error/fatal'; else echo '[OK]   Fluentd recent logs'; fi
exit "$failed"
