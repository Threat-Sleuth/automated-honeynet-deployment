#!/bin/sh

# Start vsftpd
/usr/sbin/vsftpd /etc/vsftpd.conf &

# Wait for the log file to be created
while [ ! -f /var/log/vsftpd.log ]; do
  sleep 1
done

# Follow the log
tail -F /var/log/vsftpd.log
