#!/usr/bin/env bash
set -Eeuo pipefail

SMB_USER="${SMB_USER:-smbuser}"
SMB_PASSWORD="${SMB_PASSWORD:-password}"

if ! getent group smbusers >/dev/null; then
  groupadd --system smbusers
fi

if ! id "$SMB_USER" >/dev/null 2>&1; then
  useradd --system --no-create-home --shell /usr/sbin/nologin --gid smbusers "$SMB_USER"
fi

printf '%s\n%s\n' "$SMB_PASSWORD" "$SMB_PASSWORD" | smbpasswd -a -s "$SMB_USER"
smbpasswd -e "$SMB_USER"

chown -R "$SMB_USER":smbusers /share
chmod 0770 /share

testparm -s /etc/samba/smb.conf >/dev/null
exec smbd --foreground --no-process-group --debug-stdout
