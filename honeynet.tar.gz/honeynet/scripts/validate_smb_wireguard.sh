#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

ok(){ printf '[OK] %s\n' "$*"; }
warn(){ printf '[WARN] %s\n' "$*" >&2; }
fail(){ printf '[ERROR] %s\n' "$*" >&2; exit 1; }

for c in smb-normalidad smb-pentesting vpn_normalidad vpn_pentesting; do
  docker inspect "$c" >/dev/null 2>&1 || fail "Missing container: $c"
done

for c in smb-normalidad smb-pentesting; do
  docker exec "$c" testparm -s >/dev/null 2>&1 || fail "Invalid Samba configuration in $c"
  docker exec "$c" sh -c "dpkg -s samba-vfs-modules >/dev/null 2>&1" || fail "samba-vfs-modules missing in $c"
  if docker exec "$c" grep -Eq '^[[:space:]]*(vfs objects[[:space:]]*=[[:space:]]*full_audit|full_audit:)' /etc/samba/smb.conf; then
    fail "Legacy full_audit configuration remains in $c"
  fi
  docker exec "$c" grep -Eq 'log level[[:space:]]*=[[:space:]]*3 auth_audit:3' /etc/samba/smb.conf || fail "Native Samba log level missing in $c"
  ok "$c configuration"
done

for c in vpn_normalidad vpn_pentesting; do
  docker exec "$c" wg show wg0 >/dev/null 2>&1 || fail "WireGuard interface unavailable in $c"
  ok "$c wg0"
done

for d in logs/smb_normalidad logs/smb_pentesting logs/vpn_normalidad logs/vpn_pentesting; do
  [[ -d "$d" ]] || fail "Missing log directory: $d"
done

warn "Peer handshake is a runtime test. Create a client and verify 'latest handshake' and RX/TX counters as documented."
ok "SMB/WireGuard static validation passed"
