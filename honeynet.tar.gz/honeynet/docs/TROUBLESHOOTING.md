# Troubleshooting

## Compose validation fails

Run:

```bash
docker compose config
```

Use the full output rather than `--quiet` to locate indentation, nesting or interpolation errors.

## Fluentd prevents containers from starting

Confirm that Fluentd is running and listening on port 24224:

```bash
docker ps --filter name=fluentd
docker logs fluentd
docker compose restart fluentd
```

The Compose services use asynchronous Fluentd connection mode, but Fluentd should still be started first.

## SMB starts but produces only startup messages

Confirm that the local custom image is being used:

```bash
docker inspect smb-normalidad --format '{{.Config.Image}}'
docker logs smb-normalidad
```

The expected image is `honeynet-samba:local`. Generate a real SMB operation before checking for VFS audit records.

## WireGuard collector reports no peers

Run inside the WireGuard server:

```bash
docker exec vpn_normalidad wg show all dump
```

An interface-only line means no peer has been configured. A peer must complete a handshake before endpoint and byte counters become useful.

## WireGuard UI is inaccessible

Check that the service uses wg-easy v15 variables: `INSECURE=true`, `INIT_ENABLED=true`, and the complete `INIT_USERNAME`, `INIT_PASSWORD`, `INIT_HOST`, `INIT_PORT` group. Legacy `WG_HOST`, `WG_DEVICE` and `PASSWORD_HASH` variables are not valid for this release. Inspect the exact container log with `docker logs vpn_normalidad` or `docker logs vpn_pentesting`.

## Port collision

List host listeners before deployment:

```bash
sudo ss -lntup
```

Common conflicts involve ports 25, 80, 143, 445, 587, 993, 5433, 8000 and 9000.

## Logs are delayed

Fluentd uses file buffering. During testing, inspect both the final files and the service buffer directory. Stopping Fluentd cleanly forces pending buffers to flush.
