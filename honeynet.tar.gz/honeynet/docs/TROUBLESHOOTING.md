# Troubleshooting

## Compose validation fails

Run:

```bash
docker compose config
```

Use the full output rather than `--quiet` to locate indentation, nesting or interpolation errors.

## Fluentd prevents containers from starting

Confirm that Fluentd is running and listening on port 24224:

```bash
docker ps --filter name=fluentd
docker logs fluentd
docker compose restart fluentd
```

The Compose services use asynchronous Fluentd connection mode, but Fluentd should still be started first.

## SMB starts but produces only startup messages

Confirm that the local custom image is being used:

```bash
docker inspect smb-normalidad --format '{{.Config.Image}}'
docker logs smb-normalidad
```

The expected image is `honeynet-samba:local`. Generate a real SMB operation before checking for VFS audit records.

## WireGuard collector reports no peers

Run inside the WireGuard server:

```bash
docker exec vpn_normalidad wg show all dump
```

An interface-only line means no peer has been configured. A peer must complete a handshake before endpoint and byte counters become useful.

## WireGuard UI is inaccessible

Check the container environment and ensure `PASSWORD_HASH`, not `PASSWORD`, is configured. In Compose, bcrypt dollar signs must be escaped as `$$`.

## Port collision

List host listeners before deployment:

```bash
sudo ss -lntup
```

Common conflicts involve ports 25, 80, 143, 445, 587, 993, 5433, 8000 and 9000.

## Logs are delayed

Fluentd uses file buffering. During testing, inspect both the final files and the service buffer directory. Stopping Fluentd cleanly forces pending buffers to flush.
