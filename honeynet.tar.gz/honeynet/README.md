
## SMB and WireGuard validation (v2.1.3)

The v2.1.3 stable research baseline includes validated SMB file operations and validated WireGuard tunnels with real peer handshakes and bidirectional traffic.

Detailed root-cause analysis, recovery procedures, commands, and acceptance criteria are available in:

- [`docs/SMB_WIREGUARD_TROUBLESHOOTING.md`](docs/SMB_WIREGUARD_TROUBLESHOOTING.md)

After deployment, run the static service checks with:

```bash
cd /opt/honeynet/honeynet
sudo ./scripts/validate_smb_wireguard.sh
```

WireGuard handshake validation requires a real external client and therefore remains an explicit runtime test.
