# Automated Honeynet Deployment v2.1.4

## Corrective release — Debian Bullseye FTP image rebuild

This release preserves the validated v2.1.3 research baseline and changes only the
shared FTP Dockerfile's Debian APT package sources and installation command.

- Uses signed Debian Bullseye snapshot repositories dated 2024-06-01 for FTP.
- Avoids 404 errors observed with live bullseye-security package references.
- Keeps the FTP user, password, service configuration, port mappings and startup unchanged.
- Does not alter the other seven service families, Docker Compose, logging or networking.
- Includes refreshed release integrity hashes and validation of the FTP snapshot configuration.

**Security note:** This historical snapshot intentionally freezes older packages,
which may lack later security fixes. Use only in an isolated, controlled research
environment; do not expose these experimental services directly to the Internet.

**Validation:** The snapshot package installation was independently demonstrated
on Debian Bullseye by the operator. Release structure and checksums are validated
by the bundled validator. A full Docker build and clean Ubuntu deployment must
still be tested by the operator before considering v2.1.4 operationally validated.
