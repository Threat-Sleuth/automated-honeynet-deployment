#!/usr/bin/env python3
"""Emit structured WireGuard peer-state changes as one JSON object per line."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from typing import Dict, Tuple

POLL_INTERVAL = max(float(os.getenv("POLL_INTERVAL", "2")), 0.5)
ZONE = os.getenv("COLLECTOR_ZONE", "unknown")

PeerState = Tuple[str, int, int, int]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def run_wg_dump() -> str:
    proc = subprocess.run(
        ["wg", "show", "all", "dump"],
        check=False,
        capture_output=True,
        text=True,
        timeout=10,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or f"wg exited with {proc.returncode}")
    return proc.stdout


def parse_dump(text: str) -> Dict[str, dict]:
    peers: Dict[str, dict] = {}
    current_interface = None

    for raw_line in text.splitlines():
        fields = raw_line.split("\t")
        if len(fields) == 5:
            current_interface = fields[0]
            continue
        if len(fields) < 8 or current_interface is None:
            continue

        public_key = fields[0]
        endpoint = fields[2]
        allowed_ips = fields[3]
        latest_handshake = int(fields[4] or 0)
        rx_bytes = int(fields[5] or 0)
        tx_bytes = int(fields[6] or 0)
        persistent_keepalive = fields[7]

        peers[f"{current_interface}:{public_key}"] = {
            "interface": current_interface,
            "peer": public_key,
            "endpoint": endpoint,
            "allowed_ips": allowed_ips,
            "latest_handshake": latest_handshake,
            "rx_bytes": rx_bytes,
            "tx_bytes": tx_bytes,
            "persistent_keepalive": persistent_keepalive,
        }
    return peers


def state_of(peer: dict) -> PeerState:
    return (
        peer["endpoint"],
        peer["latest_handshake"],
        peer["rx_bytes"],
        peer["tx_bytes"],
    )


def emit(event: dict) -> None:
    print(json.dumps(event, separators=(",", ":"), sort_keys=True), flush=True)


def main() -> int:
    previous: Dict[str, PeerState] = {}
    last_error = None

    emit({
        "timestamp": utc_now(),
        "service": "wireguard",
        "zone": ZONE,
        "event": "collector_started",
        "poll_interval": POLL_INTERVAL,
    })

    while True:
        try:
            peers = parse_dump(run_wg_dump())
            current = {key: state_of(peer) for key, peer in peers.items()}

            for key, peer in peers.items():
                if previous.get(key) != current[key]:
                    emit({
                        "timestamp": utc_now(),
                        "service": "wireguard",
                        "zone": ZONE,
                        "event": "peer_state_changed",
                        **peer,
                    })

            for key in previous.keys() - current.keys():
                interface, public_key = key.split(":", 1)
                emit({
                    "timestamp": utc_now(),
                    "service": "wireguard",
                    "zone": ZONE,
                    "event": "peer_removed",
                    "interface": interface,
                    "peer": public_key,
                })

            previous = current
            last_error = None
        except Exception as exc:  # collector must stay alive and retry
            message = str(exc)
            if message != last_error:
                emit({
                    "timestamp": utc_now(),
                    "service": "wireguard",
                    "zone": ZONE,
                    "event": "collector_error",
                    "error": message,
                })
                last_error = message

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    sys.exit(main())
