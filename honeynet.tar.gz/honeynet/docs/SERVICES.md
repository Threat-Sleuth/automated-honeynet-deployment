# Service inventory

| Family | Normalidad | Pentesting |
|---|---|---|
| SSH | `ssh_normalidad` | `ssh_pentesting` |
| FTP | `ftp_normalidad` | `ftp_pentesting` |
| DVWA | `dvwa_normalidad` | `dvwa_pentesting` |
| Reverse proxy | `reverse_proxy_normalidad` | `reverse_proxy_pentesting` |
| Mail | `mailserver_normalidad` | `mailserver_pentesting` |
| PostgreSQL | `db_normalidad` | `db_pentesting` |
| FastAPI | `api_normalidad` | `api_pentesting` |
| SMB | `smb_normalidad` | `smb_pentesting` |
| WireGuard | `wireguard_normalidad` | `wireguard_pentesting` |
| WG collector | `wg_collector_normalidad` | `wg_collector_pentesting` |

Infrastructure services: `fluentd` and `portainer`.
