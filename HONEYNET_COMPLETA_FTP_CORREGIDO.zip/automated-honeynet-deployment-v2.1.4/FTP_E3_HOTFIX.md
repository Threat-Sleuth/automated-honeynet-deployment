# FTP pentesting correction integrated into full v2.1.4 release

The included `honeynet.tar.gz` contains the corrected `honeynet/compose.yml` and `honeynet/ftp/start-pentesting.sh`. FTP pentesting uses passive ports 21111-21121, edits only the container's writable config and supervises vsftpd.

**Candidate only:** the original SIGSEGV root cause remains unproven. Verify sustained stability and actual FTP operations on Ubuntu/Kali before publication.

This is a complete archive based on the provided v2.1.4 distribution, including installer, uninstaller, validation script and nested deployment archive. Back up the live honeynet and D1 evidence before deploying.
