# Logging architecture

Docker sends container stdout/stderr to Fluentd through the `fluentd` logging driver. Fluentd writes per-service JSON records beneath `logs/`.

## Tag map

| Tag | Destination family |
|---|---|
| `normalidad.ssh` / `pentesting.ssh` | SSH |
| `normalidad.ftp` / `pentesting.ftp` | FTP |
| `normalidad.mailserver` / `pentesting.mailserver` | Mail |
| `normalidad.db` / `pentesting.db` | PostgreSQL |
| `normalidad.api` / `pentesting.api` | REST API |
| `normalidad.smb` / `pentesting.smb` | SMB |
| `normalidad.vpn` / `pentesting.vpn` | WireGuard and collector |

DVWA request telemetry is written by the Mitmproxy logger add-on to the mounted DVWA log directories.

## SMB

The custom Samba image runs `smbd` in the foreground with debug output directed to stdout. The `full_audit` VFS module records successful and failed operations with user, client, machine and share context.

## WireGuard

The WireGuard containers themselves mainly emit lifecycle information. The collector shares each server's network namespace and calls `wg show all dump`. A JSON event is emitted when endpoint, handshake, received-byte or transmitted-byte state changes.

This is state-change telemetry rather than packet capture. It intentionally avoids storing tunnel payloads.
